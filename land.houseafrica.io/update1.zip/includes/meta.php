<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="keywords" content="">
<link href="assets/css/page.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">
<link rel="icon" href="assets/img/favicon.png">
<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script> 
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
<style type="text/css">
  .pd-2{
    padding: 2%
  }
  .pd-3{
    padding: 3%
  }
  .pd-4{
    padding: 4%
  }
  .pd-5{
    padding: 5%
  }
  .pd-6{
    padding: 6%
  }
  .pd-7{
    padding: 7%
  }
  #map_canvas {
    height: 100%;  /* The height is 400 pixels */
    width: 100%;  /* The width is the width of the web page */
   }
   .tada{
   	background: #ffffff;
   	padding: 1%;
   	margin-bottom: 2%
   }
</style>
