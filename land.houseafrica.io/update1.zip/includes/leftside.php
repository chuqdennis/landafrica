 <div id="leftSide">
            <nav class="leftNav scrollable">
                <div class="search">
                    <span class="searchIcon icon-magnifier"></span>
                    <input type="text" placeholder="Search for Land Id, Locations...">
                    <div class="clearfix"></div>
                </div>
                <ul>
                    <li><a href="#"><span class="navIcon icon-compass"></span><span class="navLabel">Explorer</span></a></li>
                    <li><a href="#"><span class="navIcon icon-compass"></span><span class="navLabel">Find Land</span></a></li>
                    
                </ul>
            </nav>
        </div>